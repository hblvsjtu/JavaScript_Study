/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2018-04-26 16:25:30
 * @version $Id$
 */

console.log("加载index.js完成");

 				