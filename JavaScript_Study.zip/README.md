# JavaScript_Study
正如巴基斯坦和卡巴斯基，JavaScript和Java也没有半毛钱的关系。本来以来只要学点皮毛就可以了，后来看到网上鹅厂和网易他们的校招面试题，感觉这点皮毛的知识远远不够用，所以潜下心来系统地学习JavaScript。至于为什么选这本书《JavaScript权威指南》（简称‘犀牛书’）这本书，一方面是看到网上的推荐，另一方面是这本书够厚重^_ ^  
  
  
>> 地址：https://github.com/hblvsjtu/JavaScript_Study/blob/master/JavaScript_Study.pdf
